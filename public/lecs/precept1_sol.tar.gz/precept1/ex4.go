package main

import "fmt"

func reverse(s []int) {

	for i := 0; i < len(s)/2; i++ {
		temp := s[i]
		s[i] = s[len(s)-1-i]
		s[len(s)-1-i] = temp
	}
}

func main() {

	s := []int{1, 2, 3, 4, 5}
	fmt.Printf("unreversed %+v\n", s)

	reverse(s)
	fmt.Printf("reversed: %+v\n", s)
}
