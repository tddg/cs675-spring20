package main

import "fmt"

func main() {

	a := 1
	b := 1

	fmt.Printf("%d %d ", a, b)

	for i := 2; i < 10; i++ {
		fmt.Printf("%d ", a+b)
		temp := b
		b = a + b
		a = temp
	}
	fmt.Println()
}
